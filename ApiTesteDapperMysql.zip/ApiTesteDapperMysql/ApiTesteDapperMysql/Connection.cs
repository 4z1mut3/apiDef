﻿using Dapper;
using MySql.Data.MySqlClient;
namespace ApiTesteDapperMysql
{
    public class Connection
    {
        String? StrConnection { get; set; }
        Boolean IsConnected { get; set; }

       

    }
}
