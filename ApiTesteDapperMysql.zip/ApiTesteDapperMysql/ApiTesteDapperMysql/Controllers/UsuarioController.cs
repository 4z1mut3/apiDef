﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using static ApiTesteDapperMysql.Usuario;
using static SqlFactory.UsuarioSql;

namespace ApiTesteDapperMysql.Controllers
{
    [ApiController]
    [Route("api/[controller]/")]
    public class UsuarioController : ControllerBase
    {
        private IConfiguration _configuration;
        private SqlFactory.UsuarioSql _sqlUsuario;

        public UsuarioController(IConfiguration configuration, SqlFactory.UsuarioSql sqlUsuario) {
            _configuration = configuration;            
            _sqlUsuario = sqlUsuario;
        }

        [HttpGet]
        public IActionResult Get() {                
            try {      
                using var con = new MySqlConnection(_configuration.GetConnectionString("conn"));
                var usuarios = con.Query<Usuario>(_sqlUsuario.listarUsuarios);
                return Ok(usuarios);
            }
            catch (MySqlException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Post(Usuario usuario) {            
            try
            {                
                using (IDbConnection db = new MySqlConnection(_configuration.GetConnectionString("conn")))
                {
                    Usuario user = usuario;                  
                    var newTeste = db.Execute(_sqlUsuario.CadastrarUsuario, user);
                    return Ok("funciona");
                }                
            }
            catch (MySqlException ex)
            {
                return BadRequest(ex.Message);
            }        
        }
  
        [HttpPut]       
        public async Task<IActionResult> Put(Usuario User)
        {
            try {                      
                using (IDbConnection db = new MySqlConnection(_configuration.GetConnectionString("conn")))
                {                     
                    var rowAffected = await db.ExecuteAsync(_sqlUsuario.AtualizarUsuario, User);
                    if (rowAffected > 0) {
                        return Ok($"Usuario {User.IdUsuario} atualizado com sucesso!");
                    }
                    else
                    {
                        return BadRequest($"Usuario não encontrado: {User.IdUsuario} !");
                    }                    
                }
            }catch (MySqlException ex)
            {
                return BadRequest($"Não foi possivel usuario: {User.IdUsuario} !");
            }
        }

            [HttpDelete]
            public async Task<IActionResult> Delete(Usuario User)
            {
                try
                {
                    using (IDbConnection db = new MySqlConnection(_configuration.GetConnectionString("conn")))
                    {               
                        var rowAffected = await db.ExecuteAsync(_sqlUsuario.DeletarUsuario, User);
                        if (rowAffected > 0)
                        {
                            return Ok($"Usuario {User.IdUsuario} apagado com sucesso!");
                        }
                        else
                        {
                            return BadRequest($"Usuario não encontrado: {User.IdUsuario} !");
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    return BadRequest($"Não foi possivel usuario: {User.IdUsuario} !");
                }
            }
        }
    }

