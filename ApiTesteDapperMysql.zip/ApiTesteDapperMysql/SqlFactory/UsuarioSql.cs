﻿
namespace SqlFactory
{
    public class UsuarioSql
    {        
        public string listarUsuarios {
            get { return @" SELECT IdUsuario, Nome, Email FROM usuario "; }
        }
        public string CadastrarUsuario
        {
            get { 
                return @" INSERT INTO usuario (Nome, Email) VALUES (@Nome, @Email) ";
            }
        }
        public string AtualizarUsuario
        {
            get{    
                return  @" UPDATE usuario 
                           SET Nome = @Nome, Email = @Email 
                           WHERE IdUsuario = @idUsuario "; 
            }
        }
        public string DeletarUsuario
        {
            get{ 
                return @" DELETE FROM usuario WHERE IdUsuario = @idUsuario ";
            }
        }
    }
}